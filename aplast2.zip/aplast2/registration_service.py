import re


# Custom Exception for Invalid Email
class InvalidEmailError(ValueError):
    def __init__(self, email):
        super().__init__(f"Invalid email format: {email}")


# Custom Exception for Underage Users
class UnderageError(Exception):
    def __init__(self, age):
        super().__init__(f"User age {age} is below minimum age requirement of 18")


class RegistrationService:

    def register_user(self, email: str, age: int) -> bool:

        # Internal invariant check
        assert isinstance(age, int), "Age must be an integer"

        # Check null or empty email
        if email is None or email.strip() == "":
            raise InvalidEmailError(email)

        # Email regex pattern
        pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"

        # Validate email format
        if not re.match(pattern, email):
            raise InvalidEmailError(email)

        # Age validation
        if age < 18:
            raise UnderageError(age)

        return True
