from registration_service import (
    RegistrationService,
    InvalidEmailError,
    UnderageError
)

service = RegistrationService()

print("=== User Registration System ===")

# Take user input
email = input("Enter your email: ")
age = int(input("Enter your age: "))

try:
    result = service.register_user(email, age)

    if result:
        print("Registration Successful!")

except InvalidEmailError as e:
    print(e)

except UnderageError as e:
    print(e)

except AssertionError as e:
    print(e)

except Exception as e:
    print("Unexpected Error:", e)
